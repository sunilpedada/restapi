from django.apps import AppConfig


class ApiviewsappConfig(AppConfig):
    name = 'APIviewsapp'
