from rest_framework import serializers
from.models import employees
class empSerializer(serializers.ModelSerializer):
    class Meta:
        model = employees
        fields =["id","name","salary","address","dob"]
