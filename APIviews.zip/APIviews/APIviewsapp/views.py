from django.shortcuts import render
from.models import employees
from rest_framework .views import APIView
from rest_framework import status
from.serialization import serializingemp
from rest_framework.response import Response
from rest_framework.generics import ListAPIView,CreateAPIView,RetrieveAPIView
# Create your views here.
#class apiviews(APIView):
    #def get(self,format=None):
        #queryset = employees.objects.all()
        #serializer=serializingemp(queryset,many=True)
        #return Response(serializer.data)
#class apiviews(ListAPIView):
    #queryset = employees.objects.all()
    ##serializer_class=serializingemp
    #def get_queryset(self):
        #queryset = employees.objects.all()
        #id=self.request.GET.get("id")
        #if id is not None:
            #queryset=queryset.filter(id__exact=id)
        #return queryset
#class apiviews(CreateAPIView):
    #qs=employees.objects.all()
    #serializer_class = serializingemp
class apiviews(RetrieveAPIView):
