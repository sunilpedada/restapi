from  rest_framework import serializers
class nameserializers(serializers.Serializer):
    name=serializers.CharField(max_length=10)