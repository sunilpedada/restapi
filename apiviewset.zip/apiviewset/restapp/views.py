from django.shortcuts import render
from django.http import HttpResponse
from.serialization import nameserializers
from rest_framework.response import Response
from django.http import JsonResponse
from rest_framework.views import APIView
# Create your views here.
class testapiview(APIView):
    def get(self,request,*args,**kwargs):
        employees={"name":"x","id":101,"salary":20000}
        return Response(employees)
    def post(self,request,*args,**kwargs):
        serializer=nameserializers(data=request.data)
        if serializer.is_valid():
            name=serializer.data.get("name")
            msg="name:{}".format(name)
            return HttpResponse(name)
        else:
            return HttpResponse(serializer.errors,status=400)
    def put(self, request, *args, **kwargs):
        return HttpResponse(" name is changed")
    def delete(self, request, *args, **kwargs):
        return  HttpResponse("name is deleted")