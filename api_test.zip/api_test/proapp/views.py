from django.shortcuts import render
from django.http import JsonResponse
from rest_framework.views import APIView
from.models import employees
# Create your views here.
class api_views(APIView):
    def get(self,request,*args,**kwargs):
        data={id=employees.id,name=employees.name,salary=employees.salary,address=employees.address,dob=employees.dob}
        return JsonResponse(data=data)

