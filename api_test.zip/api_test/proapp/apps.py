from django.apps import AppConfig


class ProappConfig(AppConfig):
    name = 'proapp'
