from rest_framework import serializers
from.models import employees
class  serializingemp(serializers.Serializer):
    class SnippetSerializer(serializers.ModelSerializer):
        class Meta:
            model = employees
            fields = ('id', 'name', 'salary', 'address', 'dob')
