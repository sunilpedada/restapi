from rest_framework import serializers
class  serializingemp(serializers.Serializer):
    id=serializers.IntegerField(read_only=True)
    name=serializers.CharField(max_length=20)
    salary=serializers.IntegerField()
    address=serializers.CharField(max_length=10)
    dob=serializers.DateField()
