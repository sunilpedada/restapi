def datavalidation(data):
    rectangle = []
    polygon= []
    line = []
    point=[]
    for q in data["labels"]:
        print(q)
        if q["type"] == "Rectangle":
            if len(q["coordinates"]) == 2:
                for t in q["coordinates"]:
                    if len(t) == 2:
                        rectangle.append(t)
        elif q["type"] == "Polygon":
            if len(q["coordinates"]) > 2:
                for e in q["coordinates"]:
                    if len(e) == 2:
                        polygon.append(e)
        elif q["type"] == "Line":
            if len(q["coordinates"]) ==2:
                for r in q["coordinates"]:
                    if len(r) == 2:
                        line.append(r)
        elif q["type"] == "point":
            if len(q["coordinates"]) ==1:
                for r in q["coordinates"]:
                    if len(r) == 2:
                        point.append(r)
        print(rectangle)