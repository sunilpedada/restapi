from django.shortcuts import render
#from.functions import validation
# Create your views here.
import json
import xml.etree.ElementTree as et
#import urllib
#import dicttoxml
#page = urllib.urlopen('http://quandyfactory.com/api/example')
#content = page.read()
#obj = json.loads(content)
#print(obj)
#{u'mylist': [u'foo', u'bar', u'baz'], u'mydict': {u'foo': u'bar', u'baz': 1}, u'ok': True}
#xml = dicttoxml.dicttoxml(obj)
#print(xml)
#<?xml version="1.0" encoding="UTF-8" ?><root><mylist><item type="str">foo</item><item type="str">bar</item>
#<item type="str">baz</item></mylist><mydict><foo type="str">bar</foo><baz type="int">1</baz></mydict>
#<ok type="bool">true</ok></root>

with open("test2.json",'r') as elements:
    data=json.load(elements)
    for q in data["labels"]:
        rectangle = []
        polygon = []
        line = []
        point = []
        for q in data["labels"]:
            print(q)
            if q["type"] == "Rectangle":
                if len(q["coordinates"]) == 2:
                    for t in q["coordinates"]:
                        if len(t) == 2:
                            rectangle.append(t)
            elif q["type"] == "Polygon":
                if len(q["coordinates"]) > 2:
                    for e in q["coordinates"]:
                        if len(e) == 2:
                            polygon.append(e)
            elif q["type"] == "Line":
                if len(q["coordinates"]) ==2:
                    for r in q["coordinates"]:
                        if len(r) == 2:
                            line.append(r)
            elif q["type"] == "point":
                if len(q["coordinates"]) ==1:
                    for r in q["coordinates"]:
                        if len(r) == 2:
                            point.append(r)
        #if rectangle!=None:
            #if polygon!=None:
                ##if line!=None:
                    #if point!=None:
                        #root=et.Element("annotations")
                        #version=et.SubElement(root,"version")
                        #version.float=1.1
                        #e2=et.Element("meta")
                        #e3=et.Element("task")
                        ##e2.append(e3)
                        #root.append(e2)
                        #labels=et.Element("labels")
                        #root.append(labels)
                        #label=et.SubElement(labels,"label")
                        #label.text=q["label"]
                        #type = et.SubElement(labels, "type")
                        #type.text = q["type"]
                        #coordinates = et.SubElement(labels, "coordinates")
                        #coordinates.text = q["coordinates"]
                        #tree=et.ElementTree(root)
                        #tree.write("test.xml")
