from django.apps import AppConfig


class FilehandlingConfig(AppConfig):
    name = 'filehandling'
