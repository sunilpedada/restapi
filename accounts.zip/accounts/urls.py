from django.conf.urls import url
from . import views
from django.contrib.auth.views import (
    logout,password_reset,password_reset_done,password_reset_confirm,password_reset_complete
)
from scancv.views import landingpage
from accounts.forms import CustomAuthForm,CustomPasswordResetForm,CustomSetPasswordForm
from accounts.views import login

urlpatterns = [
    url(r'^login/$',login, name='login'),
    url(r'^logout/$',logout,{'template_name':'logout.html'}, name='logout'),
    url(r'^register/$',views.register,name='register'),
    url(r'^profile/$',views.profile,name='profile'),
    url(r'^profile/edit/$',views.edit_profile,name='edit_profile'),
    # url(r'^profileform$',views.ProfileView.as_view(),name='ProfileView'),
    url(r'^$',landingpage,name='landingpage'),
    url(r'^change-password$',views.change_password,name='change_password'),
    url(r'^reset-password/$',password_reset,{'password_reset_form':CustomPasswordResetForm},name='reset_password'),
    url(r'^reset-password/done/$',password_reset_done,name='password_reset_done'),
    url(r'^reset-password/confirm/(?P<uidb64>[0-9A-Za-z]+)-(?P<token>.+)/$',password_reset_confirm,{'set_password_form':CustomSetPasswordForm},name='password_reset_confirm'),
    url(r'^reset-password/complete/$',password_reset_complete,name='password_reset_complete'),
    url(r'^verify-email/$',views.email_verification,name='email_verification'),
    url(r'^pricing/$',views.pricing, name='pricing'),
]
