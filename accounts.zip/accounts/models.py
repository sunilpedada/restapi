from django.db import models
from django.contrib.auth.models import (
    AbstractBaseUser, BaseUserManager
)
from django.db.models.signals import post_save
from django_mysql.models import ListTextField
from django.utils import timezone


class UserManager(BaseUserManager):
    def create_user(self, email, firstname, lastname, recruiter, password=None,is_active=True, is_staff=False, is_admin=False):
        if not email:
            raise ValueError("User must have an email address")
        if not password:
            raise ValueError("User must have a password")
        if not firstname:
            raise ValueError("User must have a firstname")
        if not lastname:
            raise ValueError("User must have a lastname")

        user_obj = self.model(
            email = self.normalize_email(email),
            firstname = firstname,
            lastname = lastname,
            recruiter = recruiter
        )
        user_obj.set_password(password)
        user_obj.is_staff = is_staff
        user_obj.is_admin = is_admin
        user_obj.is_active = is_active
        user_obj.save(using=self._db)
        return user_obj

    def create_staffuser(self, email, firstname, lastname, recruiter, password=None):
        user = self.create_user(
            email,
            firstname,
            lastname,
            recruiter,
            password=password,
            is_staff=True
        )
        return user

    def create_superuser(self, email, firstname, lastname, recruiter, password=None):
        user = self.create_user(
            email,
            firstname,
            lastname,
            recruiter,
            password=password,
            is_staff=True,
            is_admin=True
        )
        return user


class User(AbstractBaseUser):
    email = models.EmailField(max_length=255, unique=True)
    name = models.CharField(max_length=255, blank=True, null=True)
    firstname = models.CharField(max_length=255, blank=True, null=True)
    lastname = models.CharField(max_length=255, blank=True, null=True)
    recruiter = models.BooleanField(default=False)
    date_joined = models.DateTimeField(default=timezone.now, blank=True, null=True)
    last_activity = models.DateTimeField(blank=True, null=True)
    is_active = models.BooleanField(default=True)
    is_staff = models.BooleanField(default=False)
    is_admin = models.BooleanField(default=False)

    USERNAME_FIELD = 'email'
    REQUIRED_FIELDS = ['firstname','lastname','recruiter']

    objects = UserManager()

    def __str__(self):
        return self.email

    def get_full_name(self):
        return self.email

    def get_short_name(self):
        return self.email

    def has_perm(self, perm, obj=None):
        "Does the user have a specific permission?"
        # Simplest possible answer: Yes, always
        return True

    def has_module_perms(self, app_label):
        "Does the user have permissions to view the app `app_label`?"
        # Simplest possible answer: Yes, always
        return True

    # @property
    # def is_staff(self):
    #     return self.staff
    #
    # @property
    # def is_admin(self):
    #     return self.admin
    #
    # @property
    # def is_active(self):
    #     return self.active


class UserProfile(models.Model):
    user=models.OneToOneField(User,on_delete=models.CASCADE)
    ignore_keyword_list = ListTextField(base_field=models.CharField(max_length=250))
    total_usage=models.IntegerField(default=0)
    # last_resume = models.TextField(null=True, blank=True)
    # last_jd = models.TextField(null=True, blank=True)
    # last_mr = models.IntegerField(default=0)
    # last_jt = models.CharField(max_length=100,null=True,blank=True)
    email_verified = models.BooleanField(default=False)

    def __str__(self):
        return self.user.email


STATUS_CHOICES = [
    (0, "None"),
    (1, "Yet to apply"),
    (2, "Applied"),
    (3, "Interviewed"),
    (4, "Offer accepted"),
    (5, "Not selected"),
    (6, "Waiting for response")
]


class RunReport(models.Model):
    user = models.ForeignKey(User,on_delete=models.CASCADE)
    sl_no = models.IntegerField(default=0)
    job_desc = models.TextField(null=True, blank=True)
    resume = models.TextField(null=True, blank=True)
    match_rate = models.IntegerField(default=0)
    job_title = models.CharField(max_length=100,null=True,blank=True)
    time_stamp = models.DateTimeField(null=True, blank=True)
    status = models.IntegerField(choices=STATUS_CHOICES, default=0)

    def __str__(self):
        return str(self.sl_no)+' [ Match Rate: '+str(self.match_rate)+']'


def create_profile(sender, **kwargs):
    if kwargs['created']:
        user_profile=UserProfile.objects.create(user=kwargs['instance'])

post_save.connect(create_profile,sender=User)