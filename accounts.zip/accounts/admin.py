from django.contrib import admin
from django.contrib.auth import get_user_model
from accounts.models import UserProfile, RunReport

User = get_user_model()


class UserProfileAdmin(admin.StackedInline):
    model = UserProfile
    fields = (
        'user',
        'total_usage',
        'ignore_keyword_list',
        'email_verified',
    )
    readonly_fields = ['user', 'total_usage', 'ignore_keyword_list', 'email_verified']
    verbose_name = 'UserProfile'
    verbose_name_plural = 'Profile'


class RunReportAdmin(admin.StackedInline):
    model = RunReport
    classes = ['collapse']
    fields = (
        'user',
        'sl_no',
        'job_desc',
        'resume',
        'match_rate',
        'job_title',
        'status',
        'time_stamp'
    )
    verbose_name = 'RunReport'
    verbose_name_plural = 'RunReports'
    ordering = ['-sl_no']

    def get_extra(self, request, obj=None, **kwargs):
        extra = 0
        return extra


class CustomUserAdmin(admin.ModelAdmin):
    list_display = ('email', 'name', 'first_name', 'last_name', 'date_joined', 'last_activity', 'get_total_runs', 'distinct_usage')
    list_filter = ('date_joined','last_activity')
    search_fields = ('email',)
    inlines = [UserProfileAdmin, RunReportAdmin]

    class Media:
        js = ['scancv/js/jquery.min.js', 'accounts/js/collapsed_stacked_inlines.js', ]

    exclude = ('password',)
    fields = (
        ('email','name','firstname', 'lastname','recruiter',),
        'is_active',
        ('is_staff', 'is_admin'),
        ('date_joined', 'last_login', 'last_activity')
    )
    readonly_fields = ['email','name', 'firstname', 'lastname', 'recruiter', 'is_active', 'is_staff', 'is_admin', 'date_joined', 'last_login', 'last_activity']

    def first_name(self, obj):
        return obj.firstname

    def last_name(self, obj):
        return obj.lastname

    def get_total_runs(self, instance):
        return instance.userprofile.total_usage

    def distinct_usage(self, instance):
        return instance.runreport_set.all().count()

    get_total_runs.short_description = 'total_usage'

    def get_queryset(self, request):
        queryset = super(CustomUserAdmin, self).get_queryset(request)
        # queryset = queryset.order_by('email')
        return queryset


admin.site.register(User, CustomUserAdmin)