from django.shortcuts import render
from accounts.forms import RegistrationForm,EditProfileForm
from django.contrib.auth import update_session_auth_hash,get_user_model,authenticate,login as auth_login
from accounts.forms import ContactForm
from django.core.mail import EmailMessage
from django.shortcuts import redirect
from django.template.loader import get_template
from django.contrib import messages
from django.contrib.sites.shortcuts import get_current_site
from django.template.loader import render_to_string
from django.utils.http import urlsafe_base64_encode, urlsafe_base64_decode
from django.utils.encoding import force_bytes, force_text
from .tokens import account_activation_token
from accounts.forms import CustomAuthForm,CustomPasswordChangeForm
from django.urls import reverse
from siman import settings
import mailchimp
User = get_user_model()


def login(request):
    if request.method == 'POST':
        signin_form = CustomAuthForm(request.POST)
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(username=username, password=password)

        if user is not None:
            if user.is_active:
                auth_login(request, user)
                return redirect(reverse('home'))
        else:
            messages.error(request,'Username or Password Incorrect..!')
            return redirect(reverse('login'))
    else:
        signin_form = CustomAuthForm()
    return render(request, 'login.html', {'signin_form': signin_form})


def contact(request):
    form_class = ContactForm

    if request.method == 'POST':
        form = form_class(data=request.POST)

        if form.is_valid():
            contact_name = request.POST.get(
                'contact_name'
                , '')
            contact_email = request.POST.get(
                'contact_email'
                , '')
            title = request.POST.get(
                'title'
                , '')
            form_content = request.POST.get('content', '')

            # Email the profile with the
            # contact information
            template = get_template('contact_template.txt')
            context = {
                'contact_name': contact_name,
                'contact_email': contact_email,
                'title': title,
                'form_content': form_content,
            }
            content = template.render(context)

            email = EmailMessage(
                "User Feedback",
                content,
                "Feedback" + '',
                ['support@rezrunner.com'],
                headers={'Reply-To': contact_email}
            )
            email.send()
            messages.info(request, 'Your Feedback Submitted successfully!..Thank You..!!')
            return redirect('contact')

    return render(request, 'contact.html', {
        'form': form_class,
    })


# class ProfileView(TemplateView):
#     template_name = 'profile_details.html'
#
#     def get(self, request):
#         form = ProfileForm()
#         return render(request, self.template_name, {'form':form})
#
#     def post(self, request):
#         form = ProfileForm(request.POST)
#         if form.is_valid():
#             post=form.save(commit=False)
#             post.user=request.user
#             post.save()
#             return redirect('/accounts/form')
#
#         args={'form':form}
#         return render(request,self.template_name,args)


def registration_success(user):
    # current_site = get_current_site(request)
    message = render_to_string('registration_success.html', {
        'user': user,
        # 'domain': current_site.domain,
    })
    mail_subject = 'Welcome to RezRunner.com'
    to_email = user.email
    email = EmailMessage(mail_subject, message, to=[to_email])
    email.content_subtype = "html"
    email.send()


def register(request):
    if request.method=='POST':
        signup_form=RegistrationForm(request.POST)
        if signup_form.is_valid():
            if not request.POST.get('name'):
                signup_form.save()
                new_user = authenticate(username=signup_form.cleaned_data['email'],
                                        password=signup_form.cleaned_data['password1'],
                                        )
                auth_login(request, new_user)
                registration_success(request.user)

                API_KEY = settings.MAILCHIMP_API_KEY
                LIST_ID = settings.MAILCHIMP_SUBSCRIBE_LIST_ID
                api = mailchimp.Mailchimp(API_KEY)
                try:
                    api.lists.subscribe(LIST_ID, {'email': signup_form.cleaned_data['email']}, double_optin=False)
                except:
                    pass

            return redirect(reverse('welcome'))
    else:
        signup_form=RegistrationForm()
    return render(request, 'reg_login.html', {'signup_form': signup_form})


def profile(request):
    form1 = EditProfileForm(instance=request.user)
    # form2 = CustomPasswordChangeForm(data=request.POST,user=request.user)
    if request.method == 'POST':
        form2=CustomPasswordChangeForm(data=request.POST,user=request.user)
        if form2.is_valid():
            form2.save()
            update_session_auth_hash(request, form2.user)
            messages.success(request, 'Password Saved Successfully..')
            return redirect(reverse('profile'))
    else:
        form2=CustomPasswordChangeForm(user=request.user)
    if 'profile_key' not in request.session:
        request.session['profile_key'] = 0
    # Codes for displaying last scan history in profile Dashboard
    r1 = request.user.runreport_set.all().count()
    if r1 >= 4:
        r2 = r1-4
    else:
        r2 = 0
    disp_runs = []
    for x in range(r1,r2,-1):
        for res in request.user.runreport_set.all():
            if res.sl_no == x:
                disp_runs.append(res)
                break
    # End of Codes for displaying last scan history in profile Dashboard
    disp_runs.sort(key=lambda item: item.time_stamp, reverse=True)
    args = {'form1':form1,'form2':form2,'profile_key':request.session['profile_key'], 'run_history':disp_runs, 'total_new_scans': r1}
    request.session['profile_key'] = 0
    response = render(request,'profile.html',args)
    response.set_cookie('results_popup', 1)
    return response


def edit_profile(request):
    if request.method == 'POST':
        form=EditProfileForm(request.POST,instance=request.user)
        request.session['profile_key'] = 2
        if form.is_valid():
            form.save()
            return redirect(reverse('profile'))
    else:
        # form=EditProfileForm(instance=request.user)
        # args={'form':form}
        # return render(request,'edit_profile.html',args)
        return redirect(reverse('profile'))


def change_password(request):
    if request.method == 'POST':
        form=CustomPasswordChangeForm(data=request.POST,user=request.user)
        if form.is_valid():
            form.save()
            update_session_auth_hash(request, form.user)
            return redirect(reverse('profile'))
    else:
        form=CustomPasswordChangeForm(user=request.user)
    args={'form':form}
    return render(request,'change_password.html',args)


def email_verification(request):
    current_site = get_current_site(request)
    message = render_to_string('acc_active_email.html', {
        'user': request.user,
        'domain': current_site.domain,
        'uid': urlsafe_base64_encode(force_bytes(request.user.pk)).decode(),
        'token': account_activation_token.make_token(request.user),
    })
    mail_subject = 'Verification of email | Click on the link'
    to_email = request.user.email
    email = EmailMessage(mail_subject, message, to=[to_email])
    email.content_subtype = "html"
    email.send()
    messages.info(request, 'Please Check Your Mail for Instructions..')
    request.session['profile_key'] = 2
    return redirect(reverse('profile'))


def email_verification_success(user):
    # current_site = get_current_site(request)
    message = render_to_string('acc_active_email_success.html', {
        'user': user,
        # 'domain': current_site.domain,
    })
    mail_subject = 'Email verification successful'
    to_email = user.email
    email = EmailMessage(mail_subject, message, to=[to_email])
    email.content_subtype = "html"
    email.send()


def activate(request, uidb64, token):
    try:
        uid = force_text(urlsafe_base64_decode(uidb64))
        user = User.objects.get(pk=uid)
    except(TypeError, ValueError, OverflowError, User.DoesNotExist):
        user = None
    if user is not None and account_activation_token.check_token(user, token):
        # user.is_active = True
        user.userprofile.email_verified = True
        user.userprofile.save()
        # user.save()
        # login(request, user)
        email_verification_success(user)
        messages.success(request, 'Account Verification Successful..')
        return redirect(reverse('login'))
    else:
        messages.error(request, 'Activation link is invalid!')
        return redirect(reverse('home'))


def terms_conditions(request):
    return render(request,'terms_cond.html')


def pricing(request):
    return render(request , 'pricing.html')
