from django import forms
from django.contrib.auth.forms import UserCreationForm,UserChangeForm
from accounts.models import UserProfile,User
from django.contrib.auth.forms import AuthenticationForm,PasswordChangeForm, PasswordResetForm, SetPasswordForm
from django.contrib.auth import password_validation
from django.core.exceptions import ValidationError


class ProfileForm(forms.ModelForm):
    class Meta:
        model=UserProfile
        fields=(
            'total_usage',
            'ignore_keyword_list',
            # 'last_resume',
            # 'last_jd',
            # 'last_mr',
            # 'last_jt'
        )


class RegistrationForm(UserCreationForm):
    email=forms.EmailField(widget=forms.TextInput(attrs={'placeholder': 'Email','class':'form-control input-lg'}),required = True)
    password1 = forms.CharField(widget=forms.PasswordInput(attrs={'placeholder': 'Password','class':'form-control input-lg'}), required=True)
    recruiter = forms.BooleanField(required=False)
    name = forms.CharField(required=False)

    #method For removing help texts from Registration Form
    def __init__(self, *args, **kwargs):
        super(RegistrationForm, self).__init__(*args, **kwargs)
        del self.fields['password2'] # Removing Password2 field

        for fieldname in ['email', 'password1','recruiter']:
            self.fields[fieldname].help_text = None


    class Meta:
        model=User
        fields=(
            'email',
            'password1',
            'recruiter',
            'name',
        )

    def _post_clean(self):
        super()._post_clean()
        # Validate the password after self.instance is updated with form data
        # by super().
        password = self.cleaned_data.get('password1')
        if password:
            try:
                password_validation.validate_password(password, self.instance)
            except forms.ValidationError as error:
                self.add_error('password1', error)

    def save(self, commit=True):
        user=super(RegistrationForm,self).save(commit=False)
        # user.firstname = self.cleaned_data['firstname']
        # user.lastname = self.cleaned_data['lastname']
        user.email = self.cleaned_data['email']
        user.recruiter = self.cleaned_data['recruiter']
        user.name = self.cleaned_data['name']

        if commit:
            user.save()
        return user


class EditProfileForm(UserChangeForm):
    firstname = forms.CharField(widget=forms.TextInput(attrs={'placeholder': 'First Name', 'class': 'form-control input-lg'}),required=True)
    lastname = forms.CharField(widget=forms.TextInput(attrs={'placeholder': 'Last Name', 'class': 'form-control input-lg'}), required=True)
    def __init__(self, *args, **kwargs):
        super(EditProfileForm, self).__init__(*args, **kwargs)
        del self.fields['password']

    class Meta:
        model=User
        fields=(
            'firstname',
            'lastname',
            'password'
        )


class ContactForm(forms.Form):
    contact_name = forms.CharField(widget=forms.TextInput(attrs={'class': 'form-control input-lg'}))
    contact_email = forms.EmailField(widget=forms.EmailInput(attrs={'class': 'form-control input-lg'}))
    title = forms.CharField(widget=forms.TextInput(attrs={'class': 'form-control input-lg'}))
    content = forms.CharField(widget=forms.Textarea(attrs={'class': 'form-control input-lg'}),required= True)

    def __init__(self, *args, **kwargs):
        super(ContactForm, self).__init__(*args, **kwargs)
        self.fields['contact_name'].label = "Your name:"
        self.fields['contact_email'].label = "Your email:"
        self.fields['title'].label = "Title/Area:"
        self.fields['content'].label = "Describe idea or suggestion:"


class CustomAuthForm(AuthenticationForm):
    username = forms.CharField(widget=forms.TextInput(attrs={'class':'validate form-control input-lg','placeholder': 'Email'}))
    password = forms.CharField(widget=forms.PasswordInput(attrs={'placeholder':'Password','class':'form-control input-lg'}))


class CustomPasswordChangeForm(PasswordChangeForm):
    old_password = forms.CharField(widget=forms.PasswordInput(attrs={'class': 'form-control input-lg'}))
    new_password1 = forms.CharField(widget=forms.PasswordInput(attrs={'class': 'form-control input-lg'}))
    new_password2 = forms.CharField(widget=forms.PasswordInput(attrs={'class': 'form-control input-lg'}))


class CustomPasswordResetForm(PasswordResetForm):
    email = forms.EmailField(widget=forms.TextInput(attrs={'placeholder': 'Email','class':'form-control input-lg'}),required = True)

    # Validating email by checking the email exists in database or not.
    def clean_email(self):
        email = self.cleaned_data['email']
        if not User.objects.filter(email__iexact=email, is_active=True).exists():
            raise ValidationError("There is no user registered with the specified email address!")

        return email


class CustomSetPasswordForm(SetPasswordForm):
    new_password1 = forms.CharField(widget=forms.PasswordInput(attrs={'placeholder':'New Password','class': 'form-control input-lg'}))
    new_password2 = forms.CharField(widget=forms.PasswordInput(attrs={'placeholder':'Confirm New Password','class': 'form-control input-lg'}))
