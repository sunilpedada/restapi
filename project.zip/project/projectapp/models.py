from django.db import models

# Create your models here.
class projects(models.Model):
    id=models.IntegerField(primary_key=True)
    company=models.CharField(max_length=25)
    details=models.CharField(max_length=250)
    status=models.CharField(max_length=250)