from django.shortcuts import render
from rest_framework.generics import CreateAPIView,RetrieveUpdateAPIView,ListAPIView
from.serialization import empSerialize
from.models import projects
# Create your views here.
class get_projects(ListAPIView):
    queryset = projects.objects.all()
    serializer_class=empSerializer
    def get_queryset(self):
        queryset = employees.objects.all()
        id=self.request.GET.get("id")
        if id is not None:
            queryset=queryset.filter(id__exact=id)
        return queryset
class create_record(CreateAPIView):
    queryset = projects.objects.all()
    serializer_class = empSerializer
class retrieveupdatedestroy(RetrieveUpdateAPIView):
    queryset= projects.objects.all()
    serializer_class=empSerializer