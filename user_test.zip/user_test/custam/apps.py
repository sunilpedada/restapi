from django.apps import AppConfig


class CustamConfig(AppConfig):
    name = 'custam'
