"""user_test URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/2.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from custam import views
from django.conf.urls import url
#from custam.views import crud
from rest_framework import routers
from django.conf.urls import url,include
#router=routers.DefaultRouter()
#router.register("api",views.crud)

urlpatterns = [
    path('admin/', admin.site.urls),
    #url(r"",include(router.urls)),
    #url(r"^custam/$",views.rpm.as_view(),name="reg"),
    #url(r"^custam/rest$",views.dis.as_view()),
    # url(r'^rest-auth/', include('rest_auth.urls')),
    url(r'^rest-auth/registration/', include('rest_auth.registration.urls')),
    #url(r"api/authregistration",views.Registration.as_view()),
    #url(r"api/registration",views.crud.as_view()),
]
