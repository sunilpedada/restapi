from django.contrib import admin
from.models import employees
# Register your models here.
class empadmin(admin.ModelAdmin):
    list_display =["id","name","salary","address","dob"]
admin.site.register(employees,empadmin)