from.models import employees
from rest_framework .views import APIView
from rest_framework import status
from.serialization import serializingemp
from rest_framework.response import Response
from rest_framework.generics import ListAPIView,CreateAPIView,RetrieveAPIView,ListCreateAPIView,RetrieveUpdateDestroyAPIView
from rest_framework.permissions import IsAuthenticated,IsAdminUser,IsAuthenticatedOrReadOnly,DjangoModelPermissions,AllowAny
from rest_framework.authentication import TokenAuthentication
# Create your views here.
#class apiviews(APIView):
    #def get(self,format=None):
        #queryset = employees.objects.all()
        #serializer=serializingemp(queryset,many=True)
        #return Response(serializer.data)
#class apiviews(ListAPIView):
    #queryset = employees.objects.all()
    ##serializer_class=serializingemp
    #def get_queryset(self):
        #queryset = employees.objects.all()
        #id=self.request.GET.get("id")
        #if id is not None:
            #queryset=queryset.filter(id__exact=id)
        #return queryset
#class apiviews(CreateAPIView):
    #qs=employees.objects.all()
    #serializer_class = serializingemp
class apiviews(ListCreateAPIView):
    queryset = employees.objects.all()
    serializer_class=serializingemp
    authentication_classes=[TokenAuthentication]
    #permission_classes = [AllowAny]
    #permission_classes = [IsAuthenticated]
    #permission_classes = [DjangoModelPermissions]
class retrieveupdatedestroy(RetrieveUpdateDestroyAPIView):
    queryset=employees.objects.all()
    serializer_class=serializingemp
    authentication_classes = [TokenAuthentication]
    permission_classes = [AllowAny]
    #permission_classes = [IsAuthenticated]
    #permission_classes = [DjangoModelPermissions]