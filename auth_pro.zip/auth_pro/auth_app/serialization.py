from rest_framework.serializers import ModelSerializer
from.models import emp
class serializingemp(ModelSerializer):
    class Meta:
        model=emp
        fields="__all__"