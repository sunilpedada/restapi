from django.contrib import admin
from.models import emp

# Register your models here.
class adminemp(admin.ModelAdmin):
    list_display =["id","username"]
admin.site.register(emp,adminemp)