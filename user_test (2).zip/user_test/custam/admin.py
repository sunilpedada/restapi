from django.contrib import admin
from.models import users
class adminusers(admin.ModelAdmin):
    list_display = ["user","phone_number"]
admin.site.register(users,adminusers)
